GAURI STATIONERY ANDROID APK BUILD PROJECT

यह Android Studio / GitHub Actions के लिए APK बनाने वाला source project है।
ऐप का नाम: Gauri Stationery
Package: com.gauri.stationery
वेबसाइट: https://resplendent-pony-a3cadb.netlify.app/

महत्वपूर्ण:
- यह अभी APK फाइल नहीं है; यह APK बनाने का Android project है।
- यह पहला Android wrapper है जो आपकी मौजूदा HTTPS वेबसाइट को Android ऐप में खोलता है।
- वेबसाइट/Firebase की सुविधाएँ तभी काम करेंगी जब वे वेबसाइट पर सही तरह deploy और configure हों।
- इस build में अलग native document picker/upload, offline forms या push notifications नहीं जोड़े गए हैं।

GitHub से APK बनाने का तरीका:
1. GitHub पर नया repository बनाएं।
2. इस ZIP को extract करके इसकी सभी files repository में upload करें।
3. Commit/push करें और repository में Actions tab खोलें।
4. 'Build Android APK' workflow पूरा होने दें।
5. Workflow run के नीचे Artifacts में 'Gauri-Stationery-APK' डाउनलोड करें।
6. ZIP extract करके app-debug.apk मोबाइल में install करें।

यह debug APK है। ग्राहकों में बड़े पैमाने पर बांटने या Play Store के लिए अलग signed release build और सुरक्षित signing key बनानी होगी।
